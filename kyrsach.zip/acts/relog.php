<?php 
	setcookie("email", $email, time(), "/");
	header("Location: /");
?>