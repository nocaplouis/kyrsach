<?php $main_page = True ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php 	include("base.html") ?>
</head>
<body>
	<?php include("header.php") ?>

	<main class="mt-2">
		<div class="container">
			<h1>Главная</h1>
			<p>Добро пожаловать! Используйте меню слева для навигации.</p>
		</div>
	</main>
	

</body>
</html>